from django.db import models
from django.db.models import F
from django.db.models.signals import post_save
from django.dispatch import receiver


# Create your models here.
class  EMPLOYEE(models.Model):
      Emp_Id=models.CharField(primary_key=True,max_length=20)
      Dep_Id=models.ForeignKey('DEPARTMENT',on_delete=models.CASCADE)
      Emp_name=models.TextField(max_length=20)
      Salary=models.IntegerField()
      Job=models.TextField(max_length=20)
      Age=models.IntegerField()
      Choices=(('M','Male'),('F','Female'))
      Gender=models.TextField(max_length=10,choices=Choices)
      

class  DEPARTMENT(models.Model):
      Dep_Id=models.CharField(primary_key=True,max_length=20)
      Dep_name=models.TextField(max_length=20)
      No_of_employees=models.PositiveIntegerField()
      No_of_animals=models.PositiveIntegerField()

class  VEHICLES(models.Model):
      Veh_Id=models.CharField(primary_key=True,max_length=20)
      Veh_type=models.TextField(max_length=20)
      Driver_id=models.ForeignKey('EMPLOYEE',on_delete=models.SET_NULL,null=True)
      
      
class BUDGET(models.Model):
      Dep_Id=models.ForeignKey('DEPARTMENT',on_delete=models.CASCADE)
      Food_Cost=models.IntegerField()
      Salaries=models.IntegerField()
      Electric=models.IntegerField()
      Management=models.IntegerField()
      Medical=models.IntegerField() 

class ANIMALS(models.Model):
       Animal_Id=models.CharField(primary_key=True,max_length=20)
       Dep_Id=models.ForeignKey('DEPARTMENT',on_delete=models.CASCADE)
       Animal_name=models.TextField(default=None)
       Food=models.TextField(max_length=20)
       stand=(('G','good'),('B','bad'))
       Health=models.TextField(choices=stand)
       Species=models.TextField(max_length=20)
       Entry_date=models.DateField()
       Origin=models.TextField()
       
@receiver(post_save,sender=EMPLOYEE)
def update_No_of_employees(sender,**kwargs):
   emp=kwargs['instance']
   if emp.pk:
         DEPARTMENT.objects.filter(pk=emp.Dep_Id.Dep_Id).update(No_of_employees=F("No_of_employees")+1)
         


@receiver(post_save,sender=ANIMALS)
def update_No_of_animals(sender,**kwargs):
   anim=kwargs['instance']
   if anim.pk:
         DEPARTMENT.objects.filter(pk=anim.Dep_Id.Dep_Id).update(No_of_animals=F("No_of_animals")+1)
         