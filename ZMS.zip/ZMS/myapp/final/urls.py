from django.contrib import admin
from django.urls import path,re_path
from .views import *
from django.contrib.auth import views as auth_views
urlpatterns = [

path('',auth_views.LoginView.as_view(template_name="login.html"),name="login"),
path('logout/',auth_views.LogoutView.as_view(template_name="logout.html"),name="logout"),
path('home/',home,name="home"),
path('userview/',userview,name="userview"),
path('emp/',EMPLOYEECreateView.as_view(),name="employee-create"),
path('dep/',DEPARTMENTCreateView.as_view(),name="department-create"),
path('veh/',VEHICLESCreateView.as_view(),name="vehicles-create"),
path('anim/',ANIMALSCreateView.as_view(),name="animals-create"),
path('bud/',BUDGETCreateView.as_view(),name="budget-create"),
path('emp/empsearch/',empsearch,name="empsearch"),
path('dep/depsearch/',depsearch,name="depsearch"),
path('veh/vehsearch/',vehsearch,name="vehsearch"),
path('anim/animsearch/',animsearch,name="animsearch"),
path('bud/budsearch/',budsearch,name="budsearch"),
path('anim/animsearch/<str:pk>/',ANIMALSUpdateView.as_view(),name="animals-update"),
path('emp/empsearch/<str:pk>/',EMPLOYEEUpdateView.as_view(),name="employee-update"),
path('dep/depsearch/<str:pk>/',DEPARTMENTUpdateView.as_view(),name="department-update"),
path('veh/vehsearch/<str:pk>/',VEHICLESUpdateView.as_view(),name="vehicles-update"),
path('bud/budsearch/<Dep_Id>/',BUDGETUpdateView.as_view(),name="budget-update"),
path('anim/animsearch/<str:pk>/delete/',ANIMALSDeleteView.as_view(),name="animals-delete"),
path('emp/empsearch/<str:pk>/delete/',EMPLOYEEDeleteView.as_view(),name="employee-delete"),
path('dep/depsearch/<str:pk>/delete/',DEPARTMENTDeleteView.as_view(),name="department-delete"),
path('veh/vehsearch/<str:pk>/delete/',VEHICLESDeleteView.as_view(),name="vehicles-delete"),
path('bud/budsearch/<Dep_Id>/delete/',BUDGETDeleteView.as_view(),name="budget-delete"),
path('pass-reset/',auth_views.PasswordResetView.as_view(template_name="password_reset.html"),name="password_reset"),
path('pass-reset/done',auth_views.PasswordResetDoneView.as_view(template_name="password_reset_done.html"),name="password_reset_done"),
path('pass-reset-confirm/<uidb64>/<token>/',auth_views.PasswordResetConfirmView.as_view(template_name="password_reset_confirm.html",success_url="login"),name="password_reset_confirm"),

]
