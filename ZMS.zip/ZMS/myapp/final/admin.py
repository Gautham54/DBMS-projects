from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(DEPARTMENT)
admin.site.register(EMPLOYEE)
admin.site.register(ANIMALS)
admin.site.register(VEHICLES)
admin.site.register(BUDGET)
