from django.shortcuts import render,get_object_or_404,redirect
from django.urls import reverse
from django.views.generic import *
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from .models import *
from django.db.models import F
from django.db.models.signals import pre_save,post_save
from django.dispatch import receiver
# Create your views here.
@ login_required    
def home(request):
        return render(request,"zoo.html")
    
def userview(request):
    content={"animals":ANIMALS.objects.all()}    
    return render(request,"user.html",content)

class DEPARTMENTCreateView(CreateView,LoginRequiredMixin):
      model=DEPARTMENT
      fields=("__all__")    
      success_url="/home"

class EMPLOYEECreateView(CreateView,LoginRequiredMixin):
      model=EMPLOYEE
      fields=("__all__")
      success_url="/home"
class VEHICLESCreateView(CreateView,LoginRequiredMixin):
      model=VEHICLES
      fields=("__all__")   
      success_url="/home" 
class ANIMALSCreateView(CreateView,LoginRequiredMixin):
      model=ANIMALS
      fields=("__all__")    
      success_url="/home"
class BUDGETCreateView(CreateView,LoginRequiredMixin):
      model=BUDGET
      fields=("__all__") 
      success_url="/home"   
      

@login_required 
def empsearch(request):
    query=request.POST.get("name")
    if request.method=="POST":
        results=EMPLOYEE.objects.filter(Emp_Id=query)
        if results:
           return render(request,"empsearch.html",{"results":results})
        else:   
           messages.info(request,"NO MATCH FOUND")
        
        
        return render(request,"empsearch.html",{"results":results})
    else:
       return render(request,"empsearch.html")    
@login_required 
def depsearch(request):
    query=request.POST.get("name")
    if request.method=="POST":
        results=DEPARTMENT.objects.filter(Dep_name=query)
        if results:
          return render(request,"depsearch.html",{"results":results})

        else:  
          messages.error(request,"NO MATCH FOUND")
                
        return render(request,"depsearch.html",{"results":results})
    else:
       return render(request,"depsearch.html")    

@login_required 
def vehsearch(request):
    query=request.POST.get("Id")
    if request.method=="POST":
        results=VEHICLES.objects.filter(Veh_Id=query)
        if results:
           return render(request,"vehsearch.html",{"results":results})   
           
        else:   
            messages.info(request,"NO MATCH FOUND")
        return render(request,"vehsearch.html",{"results":results})
    else:
       return render(request,"vehsearch.html")    
@login_required 
def animsearch(request):
    query=request.POST.get("Id")
    if request.method=="POST":
        results=ANIMALS.objects.filter(Animal_Id=query)
        if results:
          return render(request,"animsearch.html",{"results":results})
        else:
            messages.info(request,"NO MATCH FOUND")
        return render(request,"animsearch.html",{"results":results})
    else:
       return render(request,"animsearch.html")    
@login_required 
def budsearch(request):
    query=request.POST.get("Id")
    if request.method=="POST":
        results=BUDGET.objects.filter(Dep_Id=query)
        if results:
           return render(request,"bud.html",{"results":results})   
        else:
            messages.info(request,"NO MATCH FOUND")
        return render(request,"bud.html",{"results":results})
    else:
       return render(request,"bud.html")

class ANIMALSUpdateView(UpdateView,LoginRequiredMixin):
    model=ANIMALS
    fields=("__all__")
    success_url="/anim/animsearch" 
class VEHICLESUpdateView(UpdateView,LoginRequiredMixin):
    model=VEHICLES
    fields=("__all__") 
    success_url="/veh/vehsearch"     
class EMPLOYEEUpdateView(UpdateView,LoginRequiredMixin):
    model=EMPLOYEE
    fields=("__all__")  
    success_url="/emp/empsearch"  
class DEPARTMENTUpdateView(UpdateView,LoginRequiredMixin):
    model=DEPARTMENT
    fields=("__all__")    
    success_url="/dep/depsearch"  
class BUDGETUpdateView(UpdateView,LoginRequiredMixin):
    model=BUDGET
    fields=("__all__")
    success_url="/bud/budsearch"
    def get_object(self,**kwargs):
       return get_object_or_404(BUDGET,Dep_Id=self.kwargs["Dep_Id"])   

class ANIMALSDeleteView(DeleteView,LoginRequiredMixin):
    model=ANIMALS
    fields=("__all__")
    template_name='animals_confirm_delete .html'
    success_url="/home"
    
class VEHICLESDeleteView(DeleteView,LoginRequiredMixin):
    model=VEHICLES
    fields=("__all__")
    success_url="/home"
    template_name='vehicles_confirm_delete .html'   
class EMPLOYEEDeleteView(DeleteView,LoginRequiredMixin):
    model=EMPLOYEE
    fields=("__all__")   
    success_url="/home"
     
class DEPARTMENTDeleteView(DeleteView,LoginRequiredMixin):
    model=DEPARTMENT
    fields=("__all__")
    success_url="/home"
    template_name='department_confirm_delete .html'   
class BUDGETDeleteView(DeleteView,LoginRequiredMixin):
    model=BUDGET
    fields=("__all__")
    success_url="/home"
    template_name='budget_confirm_delete .html'
    def get_object(self,**kwargs):
       return get_object_or_404(BUDGET,Dep_Id=self.kwargs["Dep_Id"])   

    
