from django.apps import AppConfig


class FinalConfig(AppConfig):
    name = 'final'
