import os
db=os.environ.get("EMAIL_PASSWORD")
print(db)