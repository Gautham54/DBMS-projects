from django.apps import AppConfig


class DairyappConfig(AppConfig):
    name = 'dairyapp'
